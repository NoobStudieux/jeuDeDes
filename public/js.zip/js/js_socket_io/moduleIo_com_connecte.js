//			moduleIo_com_inscription.js

var sha256 = require('js-sha256'); // hash password (mieux ici que client side ?) 
var session = require('cookie-session'); // Charge le middleware de sessions

function supprJoueur(pseudoDeco) // suppression de la liste des joueurs connects
{
	session.joueursConnectes.forEach(function(joueur){
		var nvlleListe = [];
		if(joueur.pseudo == pseudoDeco)
		{

		}
		else{
			nvlleListe.push(joueur);
		}
		session.joueursConnectes = nvlleListe;
	})
}
exports.comCo = function(socket){//, pseudoNouveauJ){

	socket.on('deconnexion', function(pseudoDeco) {
		supprJoueur(pseudoDeco);
		socket.broadcast.emit('majListJoueurs', session.joueursConnectes);
		console.log('socket on deconnexion ; liste : ' + session.joueursConnectes);
	});
	socket.on('jarrive', function(pseudoNouveau) {
	//	session.joueursConnectes.push(pseudoNouveau);
		socket.broadcast.emit('majListJoueurs', session.joueursConnectes);
		console.log('socket on jarrive ; liste : ');
		session.joueursConnectes.forEach(function(j){
			console.log(j.pseudo);
		})
	});
	socket.on('nouvellePartie', function(data) {
		var partie = [];
		socket.broadcast.emit('nouvellePartie', partie);
	});

	

/*	
	socket.on('isDispoPseudo', function(pseudo) {
			
			var pseudoOK = require('../js_inscription/module_inscription.js').dispoPseudo(pseudo, function(pseudoOK){
					if(pseudoOK)
					{
						socket.emit('isDispoPseudo', true);
					}
					else{	  socket.emit('isDispoPseudo', false);		}
				});
		});
		socket.on('isMailDispo', function(mail) {
			
			var pseudoOK = require('../js_inscription/module_inscription.js').dispoMail(mail, function(mailOK){
					if(mailOK)
					{
						socket.emit('isMailDispo', true);
					}
					else{	  socket.emit('isMailDispo', false);		}
				});
		});
		socket.on('infosCompte', function(infosCompte) {
			
				var connexion = require('../js_connexion/module_connexion.js').connexion();
	
				connexion.connect();
				var rapportErr = "";
				var thatsOK = true;
				
				connexion.query("SELECT * FROM membres", function(err, rows, fields) {
				if (err) throw err;
				
				rows.forEach(function(un){
					if(un.pseudo == infosCompte['pseudo'])
					{
						thatsOK = false;
						rapportErr = "inscription non réalisée : pseudo déjà pris";
					}
					if(un.mail == infosCompte['mail'])
					{
						thatsOK = false;
						rapportErr = "inscription non réalisée : mail déjà pris";
					}
				});
				});
				connexion.end(function(err){
					var tabReponse = {
						"inscrOK": thatsOK,
						"rapport": rapportErr
					};
					if(thatsOK)
					{
						// procéder à l'inscription
						
						inscription(infosCompte);
				//		tabReponse["rapport"] = 'inscription réalisée avec succès';
						socket.emit('isInscrOK', 'inscription réalisée');
						var objetMail = "confirmation d'inscription à mon site";
						var corpsMail = "Bonjour, je vous annonce par la présente que vous êtes désormais inscris sur mon site en construction. \nAccessible à cette adresse :  <a href='localhost:8080'>localhost:8080</a>. \n Rappel pseudo : " + infosCompte['pseudo'] + ",\nMot de passee : " + infosCompte['password'] + "\n$$tay tune !";
						require('../js_envoi_mail/module_mailing.js').mailIt(infosCompte['mail'], objetMail, corpsMail);
						
					}else{
						socket.emit('isInscrOK', 'inscription impossible');
					}
				});
		});
				socket.on('credentials', function(credentials) {
					Connexion(credentials, function(connecOK){
							if(connecOK)
							{
								socket.emit('ConnecOk', 'connection autorisée');
						//		cookie('connecAllowed', 'oui');
								var objJ = require('../js_joueur/js_joueur.js').joueurFromPseudo(credentials['pseudo']);
						//		console.log('coneec OK pour : ' + objJ.pseudo + "cookie :  " + cookie); // objJ.pseudo);						
								session.joueursConnectes.push(objJ);
								
							}else{
								socket.emit('errConnec', 'connection impossible');
								console.log('coneec NOK pour : ' + credentials['pseudo']);
							}
						});			
				});*/
}
