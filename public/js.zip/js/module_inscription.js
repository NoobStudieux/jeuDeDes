exports.dispoPseudo = function(pseudo, callback){
	
	var connexion = require('../js_connexion/module_connexion.js').connexion();
	
	connexion.connect();
	var pseudoDispo = true;
	var test = connexion.query("SELECT * FROM membres", function(err, rows, fields) {
				if (err) throw err;
				
				rows.forEach(function(un){
					if(un.pseudo == pseudo)
					{
						pseudoDispo = false;
					}
				});
	}); 
	connexion.end(function(err){
			callback(pseudoDispo);
		//	return pseudoDispo;
		});
}
exports.dispoMail = function(mail, callback){
	
	var connexion = require('../js_connexion/module_connexion.js').connexion();
	
	connexion.connect();
	var mailDispo = true;
	var test = connexion.query("SELECT * FROM membres", function(err, rows, fields) {
				if (err) throw err;
				
				rows.forEach(function(un){
					if(un.mail == mail)
					{
						mailDispo = false;
					}
				});
	}); 
	connexion.end(function(err){
			callback(mailDispo);
		});
	
}
