function appConfig(app)
{
/*
    essayer une fois, routage fonctionnne mais pas fichiers statiques ... 



*/
 //   var express = require('express');
    var session = require('cookie-session');
    app.set('view engine', 'ejs');
// On utilise les sessions 
app.use(session({secret: 'todotopsecret'}))
//	.use(express.static(__dirname + '../../../public')) // ne suffit pas
    .get('/', function(req, res) { 
		
		//	cookieParser.cookie('unCookie', 'valeurCook');
		//	console.log('Cookies: ', req.cookies['unCookie']);
/*
			res.cookie('unCookie', 'valeurCook'); // .send('Cookie had been set');
			var monCook = req.cookies.cookieName;
			
			console.log('Cookies: ', req.cookies['unCookie']);

			// Cookies that have been signed
			console.log('Signed Cookies: ', req.signedCookies)
			console.log('cookie >?!  :  ' + monCook);
*/
		/*
			if()
			{
				console.log('cookie existant');
			}
			else
			{
					console.log('pas de cookie ! ' + req.cookies);
			}	*/
			res.render('pages/accueil.ejs');
	})
	.get('/connexion', function(req, res){
		res.clearCookie('unCookie', { path: '/' });
		var arrayCookie = new Array(true, {"pseudo": "sacados"}, {"password": "AZDF"});
		res.cookie('unCookie', arrayCookie); // .send('Cookie had been set');
		console.log('Cookies: ', req.cookies['unCookie']);
		res.redirect('/connecte');
	})
	.get('/connecte', function(req, res){
		
			console.log('/connecte');
			var connecte = true;  // à changer /§ adapter
			
			if(connecte)
			{
					res.render('pages/Connecte.ejs', { joueurs: session.joueursConnectes} );
			}
			else
			{console.log('render pas CO');
					res.render('pages/pasConnecte.ejs');
			}
	})
    // On redirige vers root si la page demandée n'est pas trouvée 
	.use(function(req, res, next){
			res.redirect('/');
	 }); /*
    .get('/public/bootstrap/css/bootstrap.min.css', function(req, res){
			res.sendFile(__dirname + './../../../public/bootstrap/css/bootstrap.min.css');
	});
   
	.get('/public/jquery/jquery-3.1.1.js', function(req, res){
			res.sendFile(__dirname + '/public/jquery/jquery-3.1.1.js');
	})
	.get('/public/css/style_arcade.css', function(req, res){
			res.sendFile(__dirname + '/public/css/style_arcade.css');
	})
	.get('/public/bootstrap/js/bootstrap.js', function(req, res){
			res.sendFile(__dirname + '/public/bootstrap/js/bootstrap.js');
	})
	.get('/public/js/js_inscription/module_inscription.js', function(req, res){
			res.sendFile(__dirname + '/public/js/js_inscription/module_inscription.js');
	}) */

}
exports.appConfig = appConfig;