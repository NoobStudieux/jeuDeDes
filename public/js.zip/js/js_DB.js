exports.checkDB = function()
{
	var connexion = require('../js_connexion/module_connexion.js').connexion();
	connexion.connect();
	
	var query = connexion.query(`CREATE TABLE IF NOT EXISTS membres(
	
		id SMALLINT UNSIGNED UNIQUE NOT NULL AUTO_INCREMENT,
		pseudo VARCHAR(14) UNIQUE NOT NULL,
		password VARCHAR(70) NOT NULL,
		mail VARCHAR(100) UNIQUE NOT NULL,
		points INT(10),
		date_inscr DATETIME NOT NULL,
		date_last DATETIME NOT NULL,
		PRIMARY KEY ( id )	
	)
	ENGINE=INNODB`, function(err, result) {
			if(err){		console.log('erreur avec table membres : ' + err);  }
			else{		console.log('table membres OK');  }	
	});
	/*
	query = connexion.query(`CREATE TABLE IF NOT EXISTS parties(
	
		id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
		etat VARCHAR(14) NOT NULL,
		jeu VARCHAR(45) NOT NULL,
		jmax SMALLINT UNSIGNED NOT NULL,
		lanceur VARCHAR(14) NOT NULL,
		date_lancement DATETIME NOT NULL,
		date_fin DATETIME NOT NULL,
		PRIMARY KEY ( id )	
	)
	ENGINE=INNODB`, function(err, result) {
  // Neat!
			if(err){		console.log('erreur lors de crétaion table membres OK : ' + err);  }
			else{		console.log('création table membres OK');  }	
	});
	*/
	connexion.end(function(){});
}
exports.isJoueurDansListe(pseudo)
{

}
